from django.urls import path
from skky import views, views_yyh  # views.py에서 정의한 로그인 뷰를 가져옴

urlpatterns = [
    path("mypage/", views_yyh.mypage, name='마이페이지'),
    path("update_phone/", views_yyh.update_phone, name='정보수정'),
    path("reg_gift/", views_yyh.reg_gift, name='교환신청내역'),
    path("reword_plus", views_yyh.update_product_change, name='교환수량업데이트')
]