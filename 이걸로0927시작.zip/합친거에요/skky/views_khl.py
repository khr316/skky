from django.shortcuts import get_object_or_404, render, redirect
from .models import Machine, MachineUser, User, Product, Exchange, Delivery
import folium
import pandas as pd


# 기계 관리
def machine(request):
    machines = Machine.objects.all()  # 모든 기계 정보 가져오기
    
    dt = pd.read_csv("skky/data/가상기계설치.csv")

    # 평균 위도와 경도 계산
    lat = dt['machine_latitude'].mean()
    long = dt['machine_longitude'].mean()

    # Folium 지도 생성
    m = folium.Map([lat, long], zoom_start=10, tiles='OpenStreetMap')

    # 기계 마커 추가
    for i in dt.index:
        sub_lat = dt.loc[i, 'machine_latitude']
        sub_long = dt.loc[i, 'machine_longitude']
        title = dt.loc[i, 'machine_address']

        folium.Marker([sub_lat, sub_long], tooltip=title).add_to(m)

    # 지도를 HTML로 저장
    map = m._repr_html_()  # 변수 이름 수정
    
    return render(request, 'manage/machine.html', {'machines': machines,'map': map})

# 기계 페트병 수거하기
def collect_machine(request, machine_id):
    machine = get_object_or_404(Machine, id=machine_id)  # 기계 객체 가져오기
    machine.machine_pet = 0  # 페트병 수를 0으로 업데이트
    machine.save()  # 변경사항 저장
    return redirect('기계정보')  # 기계 목록 페이지로 리디렉션



# 회원 관리
def user(request):
    users = User.objects.all()
    return render(request, 'manage/user.html', {'users':users})

# 회원 삭제
def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)  # 기계 객체 가져오기
    user.user_del = 1  # 페트병 수를 0으로 업데이트
    user.save()  # 변경사항 저장
    return redirect('회원정보')  # 회원 목록 페이지로 리디렉션

# 회원 상세 정보
def user_detail(request, user_id):
    user = get_object_or_404(User, id=user_id)
    
    return render(request, "manage/user_detail.html", {'user':user})


# 상품 관리
def product(request):
    product = Product.objects.all()
    return render(request, 'manage/product.html', {'products':product})

# 상품 등록
def product_upload(request):
    if request.method == 'POST':
        # POST 요청에서 데이터 가져오기
        product_name = request.POST.get('product_name')
        product_point = request.POST.get('product_point')
        product_pet = request.POST.get('product_pet')
        image = request.POST.get('image')  # 이미지 URL

        # Product 객체 생성 및 저장
        product = Product(
            product_name=product_name,
            product_point=product_point,
            product_pet=product_pet,
            image=image,
            product_change=0  # 초기 교환 수
        )
        product.save()
        
        return redirect('상품정보')  # 상품 목록 페이지로 리디렉션 (원하는 URL로 수정)

    return render(request, 'manage/product_upload.html')

# 상품 삭제
def product_delete(request, product_id):
    product = Product.objects.get(id=product_id)
    product.delete()# 기계 객체 가져오기

    return redirect('상품정보')  # 회원 목록 페이지로 리디렉션

# 상품 수정
def product_edit(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        product.product_name = request.POST.get('product_name')
        product.product_point = request.POST.get('product_point')
        product.product_pet = request.POST.get('product_pet')
        product.image = request.POST.get('image')
        product.save()
        return redirect('상품정보')  # 수정 후 상품 목록 페이지로 리디렉션

    return render(request, 'manage/product_edit.html', {'product': product})