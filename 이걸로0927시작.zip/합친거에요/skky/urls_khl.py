from django.urls import path
from skky import views_khl  # views.py에서 정의한 로그인 뷰를 가져옴

urlpatterns = [
    path('machine/', views_khl.machine, name='기계정보'),
    path('machine/collect/<int:machine_id>/', views_khl.collect_machine, name='기계수거'),  # 수거 완료 URL 추가
    
    path('user/',views_khl.user, name='회원정보'),
    path('user/delete/<int:user_id>/', views_khl.delete_user, name='탈퇴'),
    path('user/detail/<int:user_id>/', views_khl.user_detail, name='회원상세정보'),
    
    path('product/', views_khl.product, name='상품정보'),
    path('product/upload/', views_khl.product_upload, name='상품등록'),
    path('product/delete/<int:product_id>/', views_khl.product_delete, name='상품삭제'),
    path('product/edit/<int:product_id>/', views_khl.product_edit, name='상품수정'),
       
    
    
]
