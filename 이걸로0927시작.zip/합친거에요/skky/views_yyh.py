from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib import messages
from .models import User, Product, Exchange, Delivery, Machine, MachineUser

def main(request):
    return render(request, 'main.html')  # 메인 페이지를 렌더링

def admin_main(request):
    return render(request, 'admin_main.html')

def login_action(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 사용자 인증
        user = User.objects.filter(username=username).first()  # username으로 사용자 검색

        if user and user.password == password:  # 비밀번호를 평문으로 비교
            
            #request.session['user_id'] = user.id  # 세션에 사용자 ID 저장
            login(request, user)
            return redirect('main')  # 로그인 성공 후 메인 페이지로 리디렉션
        else:
            messages.error(request, '아이디 또는 비밀번호가 잘못되었습니다.')
            return render(request, 'user/login.html') # 실패 시 로그인 페이지로 돌아감

    return render(request, 'user/login.html')

    

def signup(request):
    if request.method == 'POST':
        # 폼에서 사용자 정보 받아오기
        username = request.POST.get('username')
        password = request.POST.get('password')
        user_name = request.POST.get('user_name')
        user_phone = request.POST.get('user_phone')

        # 사용자 정보 유효성 검사
        if not username or not password or not user_name:
            messages.error(request, '아이디, 비밀번호, 이름은 필수입니다.')
            return render(request, 'user/signup.html')
        
        # 중복된 아이디 체크
        if User.objects.filter(username=username).exists():
            messages.error(request, '이미 존재하는 아이디입니다.')
            return render(request, 'user/signup.html')

        # 사용자 정보 DB에 저장 (비밀번호 해시화 생략)
        user = User.objects.create(
            username=username,
            password=password,  # 평문 비밀번호 저장
            user_name=user_name,
            user_phone=user_phone
        )
        messages.success(request, '회원가입이 완료되었습니다.')
        return redirect('login')  # 회원가입 후 로그인 페이지로 리디렉션

    # GET 요청 시 회원가입 페이지 렌더링
    return render(request, 'user/signup.html')


def logout_action(request):
    request.session.flush()
    return redirect('main')
