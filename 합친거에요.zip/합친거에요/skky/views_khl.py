from django.shortcuts import get_object_or_404, render, redirect
from .models import Machine, MachineUser, User, Product, Exchange, Delivery
import folium
import pandas as pd


# 기계 관리
def machine(request):
    machines = Machine.objects.all()  # 모든 기계 정보 가져오기
    
    dt = pd.read_csv("skky/data/가상기계설치.csv")

    # 평균 위도와 경도 계산
    lat = dt['machine_latitude'].mean()
    long = dt['machine_longitude'].mean()

    # Folium 지도 생성
    m = folium.Map([lat, long], zoom_start=10, tiles='OpenStreetMap')

    # 기계 마커 추가
    for i in dt.index:
        sub_lat = dt.loc[i, 'machine_latitude']
        sub_long = dt.loc[i, 'machine_longitude']
        title = dt.loc[i, 'machine_address']

        folium.Marker([sub_lat, sub_long], tooltip=title).add_to(m)

    # 지도를 HTML로 저장
    map = m._repr_html_()  # 변수 이름 수정
    
    return render(request, 'manage/machine.html', {'machines': machines,'map': map})


def collect_machine(request, machine_id):
    machine = get_object_or_404(Machine, id=machine_id)  # 기계 객체 가져오기
    machine.machine_pet = 0  # 페트병 수를 0으로 업데이트
    machine.save()  # 변경사항 저장
    return redirect('기계정보')  # 기계 목록 페이지로 리디렉션


# 회원 관리
def user_manage(request):
    users = User.objects.all()
    return render(request, 'manage/user.html', {'users':users})

def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)  # 기계 객체 가져오기
    user.user_del = 1  # 페트병 수를 0으로 업데이트
    user.save()  # 변경사항 저장
    return redirect('회원정보')  # 회원 목록 페이지로 리디렉션

def user_detail(request, user_id):
    user = get_object_or_404(User, id=user_id)
    
    return render(request, "manage/user_detail.html", {'user':user})