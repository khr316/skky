from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path("admin/", admin.site.urls),
    
    
    # 관리자
    path('machine/', views.machine, name='기계정보'),
    path('machine/collect/<int:machine_id>/', views.collect_machine, name='기계수거'),  # 수거 완료 URL 추가
    
    path('user/',views.user_manage, name='회원정보'),
    path('user/delete/<int:user_id>/', views.delete_user, name='탈퇴'),
    path('user/detail/<int:user_id>/', views.user_detail, name='회원상세정보'),
    
    
    
]

