from django.shortcuts import render

# 쿼리문 직접 작성하여 DB 사용
from django.shortcuts import render
from django.db import connection
import pandas as pd

def test(request):
    # SQL 쿼리 작성 (상품 테이블에서 데이터를 가져옴)
    sql_query = "SELECT seq,category_name FROM Category"
    
    # pandas를 사용하여 SQL 쿼리 실행 및 DataFrame으로 변환
    df = pd.read_sql(sql_query, connection)
    
    # DataFrame을 리스트 형태로 변환하여 HTML 템플릿으로 전달
    data = df.to_dict(orient='records')
    
    # 'data_view.html' 템플릿에 data를 전달하여 렌더링
    return render(request, 'test.html', {'data': data})
