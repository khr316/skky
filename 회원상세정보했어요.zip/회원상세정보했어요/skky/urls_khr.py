from django.urls import path
from skky import views_khl, views_yyh, views_khr  # views.py에서 정의한 로그인 뷰를 가져옴

urlpatterns = [
    path('machine/', views_khr.machine, name='기계정보'),
    path('machine/collect/<int:machine_id>/', views_khr.collect_machine, name='기계수거'),  # 수거 완료 URL 추가
    
    path('user/',views_khr.user_manage, name='회원정보'),
    path('user/delete/<int:user_id>/', views_khr.delete_user, name='탈퇴'),
    path('user/detail/<int:user_id>/', views_khr.user_detail, name='회원상세정보'),
]
