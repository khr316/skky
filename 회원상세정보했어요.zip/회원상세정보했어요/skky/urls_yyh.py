from django.contrib import admin
from django.urls import path
from skky import views_khl, views_yyh, views_khr  # views.py에서 정의한 로그인 뷰를 가져옴

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', views_yyh.main, name='main'),  # 메인 페이지로 리디렉션 (임시로 main view가 필요)
    path("login/", views_yyh.login_action, name='login'),  # 로그인 URL 추가
    path("signup/", views_yyh.signup, name='signup'), # 회원가입 URL 추가
    path("logout/", views_yyh.logout_action, name='logout'),
    path("delivery_complete/<int:exchange_id>/", views_yyh.delivery_complete, name='배송완료')
]