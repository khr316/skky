from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser

# 회원정보 테이블
class User(AbstractBaseUser): 
    username = models.CharField(max_length=50, unique = True) # 아이디 (이메일로 받기) 중복체크 필요
    password = models.CharField(max_length=128) # 비밀번호
    user_name = models.CharField(max_length=50) # 이름
    user_phone = models.CharField(max_length=13) # 전화번호
    user_point = models.IntegerField(default=0) # 적립 받은 포인트 (사용하면 마이너스)
    user_sign = models.DateTimeField(default=timezone.now) # 가입 날짜
    user_del = models.BooleanField(default=0) # 탈퇴 유무
    user_pet = models.IntegerField(default=0) # 페트병 투입 수
    user_acc_point = models.IntegerField(default=0) # 적립 포인트 누적
    user_grade = models.IntegerField(default=1) # 회원 등급 (1이면 고마운분, 2면 귀한분, 3이면 천생연분)

    USERNAME_FIELD = 'username'

# 상품정보 테이블
class Product(models.Model):
    product_name = models.CharField(max_length=255) # 상품명
    product_point = models.IntegerField() # 상품 포인트
    product_pet = models.IntegerField() # 상품 만드는 데 사용된 페트병 개수
    image = models.CharField(max_length=255, null=True, blank=True)  # 이미지 URL
    product_change = models.IntegerField(default=0) # 사용자가 교환한 수

# 교환 정보 테이블
class Exchange(models.Model): 
    user = models.ForeignKey(User, on_delete=models.CASCADE) # 사용자 아이디
    product = models.ForeignKey(Product, on_delete=models.CASCADE) # 상품 아이디
    change_cnt = models.IntegerField() # 교환하는 상품 개수
    change_way = models.IntegerField(default=0) # 수령 방법 (0이면 현장수령, 1이면 배송)
    change_app_dt = models.DateTimeField(default=timezone.now) # 교환 신청 날짜
    change_dt = models.DateTimeField(null=True, blank=True) # 수령 날짜
    new = models.IntegerField(default=0) # 0이면 신규 교환, 1이면 수령 완료

# 배송 테이블
class Delivery(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE) # 사용자 아이디
    product = models.ForeignKey(Product, on_delete=models.CASCADE) # 상품 아이디
    del_address = models.CharField(max_length=255) # 배송 주소
    del_status = models.IntegerField(default=0) # 배송 상태 (0이면 배송전, 1이면 배송 완료)
    del_num = models.CharField(max_length=255) # 송장번호

# 기계 정보 테이블
class Machine(models.Model):
    machine_address = models.CharField(max_length=255) # 기계 위치 주소 (도로명)
    machine_latitude = models.CharField(max_length=255) # 위도
    machine_longitude = models.CharField(max_length=255) # 경도
    machine_capacity = models.IntegerField() # 페트병 수용 가능한 개수
    machine_pet = models.IntegerField(default=0) # 기계에 들어있는 페트병 개수 

# 기계 + 사용자 정보 테이블
class MachineUser(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE) # 사용자 아이디
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE) # 기계 아이디
    ma_us_pet = models.IntegerField() # 페트병 넣은 개수
    
