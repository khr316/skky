# import json
# import cv2
# import base64
# import multiprocessing
# from channels.generic.websocket import AsyncWebsocketConsumer
# import asyncio
# from skky.yolov8_runner import run_yolov8_models

# class CameraConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         self.cap = None
#         self.is_running = multiprocessing.Value('b', False)
#         self.frame_queue = None
#         self.results_queue = None
#         self.processes = None
#         await self.accept()

#     async def disconnect(self, close_code):
#         await self.stop_webcam()

#     async def receive(self, text_data):
#         data = json.loads(text_data)
#         if data['command'] == 'start':
#             await self.start_webcam()
#         elif data['command'] == 'stop':
#             await self.stop_webcam()

#     async def start_webcam(self):
#         if self.is_running.value:
#             return

#         self.is_running.value = True
#         self.cap = cv2.VideoCapture(0)
#         if not self.cap.isOpened():
#             return

#         self.frame_queue = multiprocessing.Queue(maxsize=10)
#         self.results_queue = multiprocessing.Queue()
#         self.processes, self.results_queue = run_yolov8_models(self.is_running, self.frame_queue)

#         while self.is_running.value:
#             ret, frame = self.cap.read()
#             if ret:
#                 if not self.frame_queue.full():
#                     self.frame_queue.put(frame)

#                 if not self.results_queue.empty():
#                     model_num, processed_frame, counts = self.results_queue.get()

#                     _, buffer = cv2.imencode('.jpg', processed_frame)
#                     frame_bytes = buffer.tobytes()
#                     frame_base64 = base64.b64encode(frame_bytes).decode('utf-8')

#                     await self.send(text_data=json.dumps({
#                         'image': frame_base64,
#                         'counts': counts  # 클래스별 개수 전송
#                     }))
#             await asyncio.sleep(0.03)

#     async def stop_webcam(self):
#         if not self.is_running.value:
#             return

#         self.is_running.value = False

#         if self.cap is not None:
#             self.cap.release()
#             self.cap = None
        
#         if self.processes:
#             for process in self.processes:
#                 process.terminate()
#                 process.join()

#         await self.close()


import json
from channels.generic.websocket import AsyncWebsocketConsumer

class YoloConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()

    async def disconnect(self, close_code):
        pass

    async def receive(self, text_data):
        # YOLOv8 결과를 수신 및 처리
        yolo_result = json.loads(text_data)

        # 클라이언트에 YOLOv8 결과 전송
        await self.send(text_data=json.dumps({
            'result': yolo_result
        }))
