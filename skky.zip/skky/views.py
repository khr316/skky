from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render, redirect
import requests
from .models import Machine, MachineUser, User, Product, Exchange, Delivery
import folium
from folium.plugins import MarkerCluster
import pandas as pd
from django.contrib.auth import login
from django.contrib.auth import logout
from django.contrib import messages
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import PasswordChangeForm
from django.db.models import Avg
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import random  # 오프셋을 위한 라이브러리

### 메인 ##############################
def main(request):
    user = request.user

    # 기본값 설정
    co2 = 0
    recent_pet = 0
    earn_point = 0
    machineuser_entries = []  # 비회원일 경우 빈 리스트 초기화

    if user.is_authenticated:
        # 로그인한 회원의 모든 투입 내역 정보 리스트 불러오기
        machineuser_entries = user.machineuser_set.all().order_by('-id')  # 모든 투입 내역 리스트

        result = user.user_pet * 0.06
        co2 = round(result, 4)

        # 최근 투입 내역
        recent_machineuser = machineuser_entries.first() # 가장 최근의 투입 내역 가져오기

        if recent_machineuser:  # recent_machineuser가 None이 아닐 때만 접근
            if user.user_pet < 300:
                recent_pet = recent_machineuser.ma_us_pet
                earn_point = recent_machineuser.ma_us_pet * 100

            elif user.user_pet < 500 and user.user_pet >= 300:
                recent_pet = recent_machineuser.ma_us_pet
                earn_point = recent_machineuser.ma_us_pet * 300

                if user.user_pet - recent_machineuser.ma_us_pet < 300:
                    recent_pet = recent_machineuser.ma_us_pet
                    earn_point = recent_machineuser.ma_us_pet * 100

            elif user.user_pet >= 500:
                recent_pet = recent_machineuser.ma_us_pet
                earn_point = recent_machineuser.ma_us_pet * 500

                if user.user_pet - recent_machineuser.ma_us_pet < 300:
                    recent_pet = recent_machineuser.ma_us_pet
                    earn_point = recent_machineuser.ma_us_pet * 100

                elif 300 <= user.user_pet - recent_machineuser.ma_us_pet < 500:
                    recent_pet = recent_machineuser.ma_us_pet
                    earn_point = recent_machineuser.ma_us_pet * 300

        else:
            recent_pet = 0
            earn_point = 0  # 최근 MachineUser가 없을 경우 기본값 설정

    else:
        co2 = 0
        recent_pet = 0
        earn_point = 0  # 비회원일 경우 기본값 설정

    return render(request, "main.html", {
        "co2": co2,
        "earn_point": earn_point,
        "recent_pet": recent_pet,
        "machineuser_entries": machineuser_entries  # 모든 투입 내역을 템플릿에 전달
    })


def aboutus(request):
    return render(request, 'aboutus.html')

def admin_main(request):
    exchange = Exchange.objects.filter(new=0)
    machine = Machine.objects.filter(machine_pet__gte=900)
        # 기계 관리
    machines = Machine.objects.all()  # 모든 기계 정보 가져오기
    
    # 기계 정보를 JSON으로 변환
    machine_data = []
    for machine in machines:
        machine_data.append({
            'id': machine.id,
            'address': machine.machine_address,
            'capacity': machine.machine_capacity,
            'pet': machine.machine_pet,
            'latitude': machine.machine_latitude,
            'longitude': machine.machine_longitude,
        })
    
    dt = pd.read_csv("skky/data/가상기계설치2.csv")

    # 평균 위도와 경도 계산
    lat = dt['machine_latitude'].mean()
    long = dt['machine_longitude'].mean()

    # Folium 지도 생성
    m = folium.Map([lat, long], zoom_start=15, tiles='OpenStreetMap')
    
    # Folium 마커 추가
    for machine in machine_data:
        folium.Marker(
            [machine['latitude'], machine['longitude']],
            tooltip=machine['address'],
            icon=folium.Icon(color='blue'),
        ).add_to(m)

    # 지도를 HTML로 저장
    map = m._repr_html_()  # 변수 이름 수정
    
    
    # 상품 관리
    product = Product.objects.all()
    
    # 회원 관리
    users = User.objects.filter(user_grade__gt=0)
    
    
    content = {"exchange":exchange, "machine":machine,
               'machines': machines, 'map': map, 'machine_data': machine_data,
               'products':product,
               'users':users}
    
    return render(request, 'admin_main.html', content)

### 로그인 ##############################
def login_action(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 사용자 인증
        user = User.objects.filter(username=username).first()  # username으로 사용자 검색

        if user and user.password == password:  # 비밀번호를 평문으로 비교
            if user.user_grade == 0:
                login(request, user)
                return redirect('관리자용')
            else:
                #request.session['user_id'] = user.id  # 세션에 사용자 ID 저장
                login(request, user)
                return redirect('main')  # 로그인 성공 후 메인 페이지로 리디렉션
        else:
            messages.error(request, '아이디 또는 비밀번호가 잘못되었습니다.')
            return render(request, 'user/login.html') # 실패 시 로그인 페이지로 돌아감

    return render(request, 'user/login.html')

### 로그아웃
def logout_action(request):
    request.session.flush()
    return redirect('main')
    
### 회원가입 ##############################
def signup(request):
    if request.method == 'POST':
        # 폼에서 사용자 정보 받아오기
        username = request.POST.get('username')
        password = request.POST.get('password')
        user_name = request.POST.get('user_name')
        user_phone = request.POST.get('user_phone')

        # 사용자 정보 유효성 검사
        if not username or not password or not user_name:
            messages.error(request, '아이디, 비밀번호, 이름은 필수입니다.')
            return render(request, 'user/signup.html')
        
        # 중복된 아이디 체크
        if User.objects.filter(username=username).exists():
            messages.error(request, '이미 존재하는 아이디입니다.')
            return render(request, 'user/signup.html')

        # 사용자 정보 DB에 저장 (비밀번호 해시화 생략)
        user = User.objects.create(
            username=username,
            password=password,  # 평문 비밀번호 저장
            user_name=user_name,
            user_phone=user_phone
        )
        messages.success(request, '회원가입이 완료되었습니다.')
        return redirect('login')  # 회원가입 후 로그인 페이지로 리디렉션

    # GET 요청 시 회원가입 페이지 렌더링
    return render(request, 'user/signup.html')

# get_user_model()을 사용해 현재 커스텀 사용자 모델을 가져옴
User = get_user_model()

def check_username(request):
    username = request.GET.get('username', None)
    if username:
        # 커스텀 사용자 모델에서 username을 조회
        is_taken = User.objects.filter(username=username).exists()
        return JsonResponse({'is_taken': is_taken})
    else:
        return JsonResponse({'error': 'username not provided'}, status=400)

### 아이디, 비밀번호 찾기 ##############################
def find_id(request):
    found_id = None  # 초기화

    if request.method == "POST":
        user_name = request.POST.get('user_name')
        user_phone = request.POST.get('user_phone')

        # 사용자 이름과 전화번호가 입력되었는지 확인
        if user_name and user_phone:
            # 해당 이름과 전화번호로 사용자 찾기
            try:
                user = User.objects.get(user_name=user_name, user_phone=user_phone)
                found_id = user.username  # 아이디는 username 필드에서 가져옵니다.
            except User.DoesNotExist:
                found_id = None  # 사용자가 존재하지 않을 경우 None으로 설정
        else:
            found_id = "이름과 전화번호를 입력해주세요"  # 오류 메시지

    return render(request, 'user/find_id.html', {'found_id': found_id})

def find_pw(request):
    found_pw = None

    if request.method == 'POST':
        username = request.POST.get('username')
        user_name = request.POST.get('user_name')
        user_phone = request.POST.get('user_phone')

        if username and user_name and user_phone:
            try:
                # 사용자 정보를 기반으로 비밀번호를 찾습니다.
                user = User.objects.get(username=username, user_name=user_name, user_phone=user_phone)
                found_pw = user.password
            except User.DoesNotExist:
                found_pw = None  # 사용자가 없을 경우
        else:
            found_pw = '아이디와 이름과 전화번호를 입력해주세요'

    return render(request, 'user/find_pw.html', {'found_pw': found_pw})

User = get_user_model()  # 커스텀 User 모델 사용
### 비밀번호 변경(마이페이지) ###
@login_required
def change_password(request):
    if request.method == 'POST':
        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        
        if request.user.password != current_password:
            return render(request, 'user/mypage.html', {
                'error_message': '기존 비밀번호가 잘못되었습니다.',
                'form': PasswordChangeForm(user=request.user)  # 초기화된 폼
            })

        # 새 비밀번호와 확인 비밀번호 일치 여부 확인
        if new_password != confirm_password:
            return render(request, 'user/mypage.html', {
                'error_message': '새 비밀번호와 확인 비밀번호가 일치하지 않습니다.',
                'form': PasswordChangeForm(user=request.user)  # 초기화된 폼
            })

        # 비밀번호 변경
        request.user.password = new_password  # 새 비밀번호로 변경
        request.user.save(update_fields=['password'])  # 비밀번호 필드만 업데이트

        # 세션 종료 및 로그아웃
        logout(request)  # 현재 사용자 로그아웃

        return redirect('login')  # 로그인 페이지로 리다이렉트

    return render(request, 'user/mypage.html', {'form': PasswordChangeForm(user=request.user)})





############################################ 사용자 ver ############################################

### 교환 내역 ##############################
@login_required
def exchange_history(request):
    # 로그인한 사용자의 교환 내역 가져오기
    exchanges = Exchange.objects.filter(user=request.user)

    # 디버깅 로그 추가
    print(f"User exchanges count: {exchanges.count()}")  # 교환 내역 개수 확인

    content = {
        'exchanges': exchanges,
    }
    return render(request, 'user/exchange_history.html', content)  # content 딕셔너리를 포함해 템플릿 렌더링

### 마이페이지 ##############################
@login_required
def mypage(request): 
    # 해당 회원이 신청한 교환 정보 가져오기
    exchanges = Exchange.objects.filter(user=request.user)  # request.user로 수정하여 현재 로그인한 사용자 조회

    return render(request, 'user/mypage.html', {"exchanges": exchanges})  # context key를 exchanges로 수정

# 마이페이지 정보 수정 (전화번호)
@login_required
def update_phone(request):
    var_user_phone = request.POST.get('input_user_phone')

    user_object = User.objects.get(id = request.user.id)

    user_object.user_phone = var_user_phone
    user_object.save()

    return redirect('마이페이지')


from django.shortcuts import redirect
from django.contrib import messages
from .models import Exchange, User, Product

# 교환 취소
def cancel_exchange(request):
    if request.method == "POST":
        exchange_id = request.POST.get("exchange_id")
        try:
            # 교환 내역 가져오기
            exchange = Exchange.objects.get(id=exchange_id)
            
            # 사용자에게 포인트 환불하기
            user = exchange.user
            product = exchange.product
            
            # 상품의 포인트를 사용자 계정에 다시 추가
            user.user_point += product.product_point * exchange.change_cnt  # 환불할 포인트는 상품의 포인트와 동일하다고 가정
            user.save()  # 변경된 사용자 정보 저장
            
            # 상품의 교환 수 업데이트
            product.product_change -= exchange.change_cnt  # change_cnt가 교환된 수량을 나타낸다고 가정
            product.save()  # 변경된 상품 정보 저장
            
            # 교환 내역 삭제
            exchange.delete()  # 교환 내역 삭제
            
            messages.success(request, "교환이 취소되었습니다. 포인트가 환불되었습니다.")  # 성공 메시지
            return redirect('교환내역')  # 교환 취소 후 마이페이지로 리다이렉트
        except Exchange.DoesNotExist:
            # 교환 정보가 존재하지 않을 경우 처리
            messages.error(request, "교환 정보가 존재하지 않습니다.")
            return redirect('교환내역')
        except Exception as e:
            # 예상치 못한 오류 발생 시 처리
            messages.error(request, "교환 취소 중 오류가 발생했습니다: " + str(e))
            return redirect('교환내역')
    return redirect('교환내역')  # POST가 아닐 경우 기본 동작

    
### 교환 신청

def reward_action(request):

    if request.method == "POST":
        product_id = request.POST.get('selected_product')
        product = get_object_or_404(Product, id=product_id)

        user_points = request.user.user_point  # 사용자의 현재 포인트 가져오기

        # count 최대값
        max_count = []
        
        available_products = []

        count = user_points // product.product_point  
        # 1부터 count까지의 리스트 생성
        quantity_options = list(range(1, count + 1))  
        
        max_count.append(count)
        # 상품 정보와 함께 수량 옵션 추가
        available_products.append({
            'id': product.id,
            'name': product.product_name,
            'points': product.product_point,
            'count': count,
            'quantity_options': quantity_options  # 수량 옵션 추가
        })

        # max_count가 비어 있지 않으면 a를 할당
        if max_count:
            a = max(max_count)
        else:
            a = 0  # max_count가 비어 있을 경우 기본값 설정

        b = [i for i in range(1, a + 1)]

        content = {
            "users": request.user,
            "b": b,
            "available_products": available_products,
            'product_id': product_id, 
            'product': product
        }
        
    return render(request, 'exchange/reward.html', content)
    

def reward_action_action(request):
    var_user_id = request.POST.get('user_id')
    var_product_id = request.POST.get('product_id')
    var_product_cnt = request.POST.get('quantity')
    var_change_type = request.POST.get('change_type')
    var_address = request.POST.get('address')
    var_address2 = request.POST.get('address_detail')
    var_datetime = request.POST.get('datetime')

    # 교환 기록 생성
    Exchange.objects.create(user_id=var_user_id,
                            product_id=var_product_id,
                            change_cnt=var_product_cnt,
                            change_way=var_change_type,
                            change_app_dt=var_datetime)
    
    # 배송 요청일 경우 배송 테이블에 추가
    if int(var_change_type) == 1:
        Delivery.objects.create(user_id=var_user_id,
                                product_id=var_product_id,
                                del_status=0,
                                del_address=var_address+" "+var_address2)

    # 사용자 포인트 업데이트
    user = User.objects.get(id=var_user_id)  # 사용자 객체 가져오기
    product = Product.objects.get(id=var_product_id)  # 상품 객체 가져오기
    
    # 포인트 차감
    user.user_point -= int(product.product_point) * int(var_product_cnt)
    user.save()  # 변경된 값을 저장
    
    # 상품 수량 증가
    product.product_change += int(var_product_cnt)
    product.save()

    return redirect('main')


### 페트병 투입 장면 보여줄 페이지
def petpet(request):
    users = None  # 동일한 번호를 가진 사용자 목록
    selected_user = None  # 선택된 사용자

    if request.method == "POST":
        phone_number = request.POST.get('phone_number')
        selected_user_id = request.POST.get('selected_user')

        if phone_number:
            # 사용자 선택이 아직 안된 경우 (전화번호로 조회)
            if not selected_user_id:
                # 동일한 전화번호를 가진 사용자 목록 가져오기
                users = User.objects.filter(user_phone=phone_number, user_del=False)

                if not users.exists():
                    messages.error(request, "해당 전화번호로 등록된 사용자가 없습니다.")
                elif users.count() == 1:
                    # 사용자 목록에 한 명만 있을 경우 바로 선택
                    selected_user = users.first()
                else:
                    # 사용자 목록이 여러 명인 경우 선택 폼 표시
                    messages.info(request, "해당 전화번호로 여러 명의 사용자가 등록되어 있습니다. 사용자를 선택해주세요.")
            else:
                # 사용자가 선택된 경우
                try:
                    selected_user = User.objects.get(id=selected_user_id)
                    messages.success(request, f"{selected_user.user_name}님이 선택되었습니다.")
                except User.DoesNotExist:
                    messages.error(request, "잘못된 사용자 선택입니다.")
        else:
            messages.error(request, "전화번호를 입력해주세요.")
    
    # 사용 가능한 기계 정보 가져오기
    machines = Machine.objects.filter(machine_pet__lt=1000)
    
    
    return render(request, "petpet.html", {
        "users": users, 
        "selected_user": selected_user,
        "machines": machines,
    })

def petpet_action(request):
    var_user_id = request.POST.get("user_id")
    var_machine_id = request.POST.get("machine_id")
    
    user = User.objects.get(id=var_user_id)
    machine = Machine.objects.get(id=var_machine_id)
    machine_use = int(machine.machine_capacity)-int(machine.machine_pet)

    if user.user_grade == 1:
        mul_point = 100
    elif user.user_grade == 2:
        mul_point = 200
    else:
        mul_point = 300

    id = {"user":user, "machine":machine, "machine_use":machine_use, 'mul_point':mul_point}
    
    return render(request, "index.html", id)

    
# 글로벌 실행 상태 관리 변수
is_running = False

def stop_yolo_webcam(request):
    global is_running
    is_running = False  # 실행 중 상태를 False로 설정하여 웹캠과 모델 중지
    print("YOLOv8 웹캠 감지 및 모델이 중지되었습니다.")
    return HttpResponse("YOLOv8 웹캠 감지가 중지되었습니다.")

# def petpetpet_action(request):
#     var_user_id = request.POST.get("user_id")
#     var_machine_id = request.POST.get("machine_id")
#     var_pet_cnt = request.POST.get("pet_cnt")
    
#     # 기계의 남은 용량을 계산
#     remaining_capacity = 1000 - machine.machine_pet

#     # 페트병을 투입할 수 있는지 여부 확인 ###################################추가
#     if int(var_pet_cnt) > remaining_capacity:
#         # 기계가 가득 찬 경우 메시지 출력
#         messages.error(request, "기계가 가득 찼습니다. 페트병을 더 이상 넣을 수 없습니다.")
#         return redirect('user/petpet.html')
#     else:
#         # 투입 가능한 경우 MachineUser 데이터 생성
#         MachineUser.objects.create(
#             user=user,
#             machine=machine,
#             ma_us_pet=var_pet_cnt
#         )
    
#     # 사용자 포인트 추가 + 페트병 투입 수 추가
#     user = User.objects.get(id=var_user_id)
    
    

#     # "현재" 누적 투입 페트병 수에 따라 등급별 포인트 적립
#     if user.user_grade == 1 and user.user_pet < 300:
#         user.user_pet += int(var_pet_cnt)
#         user.user_point += int(var_pet_cnt) * 100
#         user.user_acc_point += int(var_pet_cnt) * 100

#         if user.user_pet >= 300 and user.user_pet < 500:
#             user.user_grade = 2
#         elif user.user_pet >= 500:
#             user.user_grade = 3

#     elif user.user_grade == 2 and user.user_pet < 500 :
#         user.user_pet += int(var_pet_cnt)
#         user.user_point += int(var_pet_cnt) * 300
#         user.user_acc_point += int(var_pet_cnt) * 300

#         if user.user_pet >= 500:
#             user.user_grade = 3
            
#     elif user.user_grade == 3:
#         user.user_pet += int(var_pet_cnt)
#         user.user_point += int(var_pet_cnt) * 500
#         user.user_acc_point += int(var_pet_cnt) * 500
    
#     # 사용자 정보 저장
#     user.save()
        
#     # 기계 페트병 수 추가
#     machine = Machine.objects.get(id=var_machine_id)
#     machine.machine_pet += int(var_pet_cnt)
    
#     # 기계 정보 저장
#     machine.save()

#     return redirect('main')
# def petpetpet_action(request):
#     var_user_id = request.POST.get("user_id")
#     var_machine_id = request.POST.get("machine_id")
#     var_pet_cnt = request.POST.get("pet_cnt")
    
#     # 사용자와 기계를 가져오기
#     try:
#         user = User.objects.get(id=var_user_id)
#     except User.DoesNotExist:
#         messages.error(request, "존재하지 않는 사용자입니다.")
#         return redirect('user/petpet.html')

#     try:
#         machine = Machine.objects.get(id=var_machine_id)
#     except Machine.DoesNotExist:
#         messages.error(request, "존재하지 않는 기계입니다.")
#         return redirect('user/petpet.html')

#     # 기계의 남은 용량을 계산
#     remaining_capacity = 1000 - machine.machine_pet

#     # 페트병을 투입할 수 있는지 여부 확인
#     if int(var_pet_cnt) > remaining_capacity:
#         return JsonResponse({"status": "error", "message": "기계가 가득 찼습니다. 페트병을 더 이상 넣을 수 없습니다."})
#     else:
#         # 투입 가능한 경우 MachineUser 데이터 생성
#         MachineUser.objects.create(
#             user=user,
#             machine=machine,
#             ma_us_pet=var_pet_cnt
#         )
#     # 사용자 포인트 추가 + 페트병 투입 수 추가
#     user = User.objects.get(id=var_user_id)  # 중복 코드 제거 가능 (위에서 이미 user를 가져왔음)

#     # "현재" 누적 투입 페트병 수에 따라 등급별 포인트 적립
#     if user.user_grade == 1 and user.user_pet < 300:
#         user.user_pet += int(var_pet_cnt)
#         user.user_point += int(var_pet_cnt) * 100
#         user.user_acc_point += int(var_pet_cnt) * 100

#         if user.user_pet >= 300 and user.user_pet < 500:
#             user.user_grade = 2
#         elif user.user_pet >= 500:
#             user.user_grade = 3

#     elif user.user_grade == 2 and user.user_pet < 500:
#         user.user_pet += int(var_pet_cnt)
#         user.user_point += int(var_pet_cnt) * 300
#         user.user_acc_point += int(var_pet_cnt) * 300

#         if user.user_pet >= 500:
#             user.user_grade = 3
            
#     elif user.user_grade == 3:
#         user.user_pet += int(var_pet_cnt)
#         user.user_point += int(var_pet_cnt) * 500
#         user.user_acc_point += int(var_pet_cnt) * 500

#     # 사용자 정보 저장
#     user.save()
        
#     # 기계 페트병 수 추가
#     machine.machine_pet += int(var_pet_cnt)
    
#     # 기계 정보 저장
#     machine.save()

#     # 성공 후 메인 페이지로 리디렉션
#     return redirect('main')
def petpetpet_action(request):
    if request.method == 'POST':
        var_user_id = request.POST.get("user_id")
        var_machine_id = request.POST.get("machine_id")
        var_pet_cnt = request.POST.get("pet_cnt")

        # 사용자와 기계를 가져오기
        try:
            user = User.objects.get(id=var_user_id)
        except User.DoesNotExist:
            return JsonResponse({"status": "error", "message": "존재하지 않는 사용자입니다."}, status=400)

        try:
            machine = Machine.objects.get(id=var_machine_id)
        except Machine.DoesNotExist:
            return JsonResponse({"status": "error", "message": "존재하지 않는 기계입니다."}, status=400)

        # 기계의 남은 용량을 계산
        remaining_capacity = 1000 - machine.machine_pet

        # 페트병을 투입할 수 있는지 여부 확인
        if int(var_pet_cnt) > remaining_capacity:
            return JsonResponse({"status": "error", "message": "기계가 가득 찼습니다. 페트병을 더 이상 넣을 수 없습니다."}, status=400)
        else:
            # 투입 가능한 경우 MachineUser 데이터 생성
            MachineUser.objects.create(
                user=user,
                machine=machine,
                ma_us_pet=var_pet_cnt
            )

            # 사용자 포인트 추가 + 페트병 투입 수 추가
            user.user_pet += int(var_pet_cnt)
            user.user_point += int(var_pet_cnt) * 100  # 예시로 100 포인트를 추가
            user.save()

            # 기계 페트병 수 추가
            machine.machine_pet += int(var_pet_cnt)
            machine.save()

            return JsonResponse({"status": "success", "message": "페트병 투입이 완료되었습니다."}, status=200)

    return JsonResponse({"status": "error", "message": "잘못된 요청입니다."}, status=400)


def main_view(request):
    return render(request, 'main.html')


############################################ 관리자 ver ############################################

# 기계 관리
def machine(request):
    machines = Machine.objects.all()  # 모든 기계 정보 가져오기
    
    # 기계 정보를 JSON으로 변환
    machine_data = []
    for machine in machines:
        machine_data.append({
            'id': machine.id,
            'address': machine.machine_address,
            'capacity': machine.machine_capacity,
            'pet': machine.machine_pet,
            'latitude': machine.machine_latitude,
            'longitude': machine.machine_longitude,
        })
    
    dt = pd.read_csv("skky/data/가상기계설치2.csv")

    # 평균 위도와 경도 계산
    lat = dt['machine_latitude'].mean()
    long = dt['machine_longitude'].mean()

    # Folium 지도 생성
    m = folium.Map([lat, long], zoom_start=15, tiles='OpenStreetMap')
    
    # Folium 마커 추가
    for machine in machine_data:
        folium.Marker(
            [machine['latitude'], machine['longitude']],
            tooltip=machine['address'],
            icon=folium.Icon(color='blue'),
        ).add_to(m)


    # 지도를 HTML로 저장
    map = m._repr_html_()  # 변수 이름 수정
    
    return render(request, 'manage/machine.html', {'machines': machines, 'map': map, 'machine_data': machine_data})
    
# 기계 페트병 수거하기
def collect_machine(request, machine_id):
    machine = get_object_or_404(Machine, id=machine_id)  # 기계 객체 가져오기
    machine.machine_pet = 0  # 페트병 수를 0으로 업데이트
    machine.save()  # 변경사항 저장
    return redirect('관리자용')  # 기계 목록 페이지로 리디렉션

# 기계 정보 수정
def machine_edit(request, machine_id):
    machine = get_object_or_404(Machine, id=machine_id)

    if request.method == 'POST':
        machine.machine_address = request.POST.get('machine_address')
        machine.machine_capacity = request.POST.get('machine_capacity')  # 추가된 필드
        machine.machine_pet = request.POST.get('machine_pet')
        machine.save()
        return redirect('관리자용')  # 수정 후 기계 목록 페이지로 리디렉션

    return render(request, 'manage/machine_edit.html', {'machine': machine})

##############################

# 회원 관리
def user(request):
    users = User.objects.filter(user_grade__gt=0)
    return render(request, 'manage/user.html', {'users':users})

# 회원 삭제
def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)  # 기계 객체 가져오기
    user.user_del = 1  # 페트병 수를 0으로 업데이트
    user.save()  # 변경사항 저장
    return redirect('회원정보')  # 회원 목록 페이지로 리디렉션

# 회원 상세 정보
def user_detail(request, user_id):
    # 주어진 user_id로 특정 회원 정보 가져오기 (관리자가 확인하려는 회원)
    user = get_object_or_404(User, id=user_id)

    # 해당 사용자의 교환 내역 조회
    exchange_list = Exchange.objects.filter(user=user).select_related('product')

    # 조회한 정보를 템플릿에 전달
    context = {
        'user': user, # 관리자가 조회하는 회원의 정보
        'exchange_list': exchange_list,  # 해당 회원의 교환 내역
    }

    return render(request, 'manage/user_detail.html', context)




### 교환 신청한 회원 확인 ##############################
def reg_gift(request):
    all_exchange_list = Exchange.objects.select_related('user', 'product').all()
    context = {
        'exchange_list': all_exchange_list,
    }
    return render(request, 'manage/reg_gift.html', context)
    
# 교환 신청한 회원에게 배송 보내기 완료
def delivery_complete(request, exchange_id):
    exchange = get_object_or_404(Exchange, id=exchange_id) # 기계 객체 가져오기
    exchange.change_dt = timezone.now() # 배달 완료 시간을 현재 시간으로 설정
    exchange.new = 1
    exchange.save() # 변경사항 저장
    

    return redirect('교환신청내역')  # 회원 상세 정보로 리디렉션

# 교환 신청한 회원에게 배송 보내기 완료
def delivery_complete1(request, exchange_id):
    exchange = get_object_or_404(Exchange, id=exchange_id) # 기계 객체 가져오기
    exchange.change_dt = timezone.now() # 배달 완료 시간을 현재 시간으로 설정
    exchange.new = 1
    exchange.save() # 변경사항 저장
    

    return redirect('교환신청내역')  # 회원 상세 정보로 리디렉션

##############################

# 상품 관리
def product(request):
    product = Product.objects.all()
    return render(request, 'manage/product.html', {'products':product})

# 상품 등록
def product_upload(request):
    if request.method == 'POST':
        # POST 요청에서 데이터 가져오기
        product_name = request.POST.get('product_name')
        product_point = request.POST.get('product_point')
        product_pet = request.POST.get('product_pet')
        image = request.POST.get('image')  # 이미지 URL

        # Product 객체 생성 및 저장
        product = Product(
            product_name=product_name,
            product_point=product_point,
            product_pet=product_pet,
            image=image,
            product_change=0  # 초기 교환 수
        )
        product.save()
        
        return redirect('관리자용')  # 상품 목록 페이지로 리디렉션 (원하는 URL로 수정)

    return render(request, 'manage/product_upload.html')

# 상품 삭제
def product_delete(request, product_id):
    product = Product.objects.get(id=product_id)
    product.delete()# 기계 객체 가져오기

    return redirect('관리자용')  # 회원 목록 페이지로 리디렉션

# 상품 수정
def product_edit(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        product.product_name = request.POST.get('product_name')
        product.product_point = request.POST.get('product_point')
        product.product_pet = request.POST.get('product_pet')
        product.image = request.POST.get('image')
        product.save()
        return redirect('관리자용')  # 수정 후 상품 목록 페이지로 리디렉션

    return render(request, 'manage/product_edit.html', {'product': product})



############################## chat ##############################

# ### 기계 위치 확인 페이지
# def machine_confirm(request):
#     machines = Machine.objects.all()
#     # 기계 정보를 JSON으로 변환
#     machine_data = []
#     for machine in machines:
#         machine_data.append({
#             'id': machine.id,
#             'address': machine.machine_address,
#             'capacity': machine.machine_capacity,
#             'pet': machine.machine_pet,
#             'latitude': machine.machine_latitude,
#             'longitude': machine.machine_longitude,
#         })
#     dt = pd.read_csv("skky/data/가상기계설치2.csv")

#     # 평균 위도와 경도 계산
#     lat = dt['machine_latitude'].mean()
#     long = dt['machine_longitude'].mean()

#     # Folium 지도 생성
#     m = folium.Map([lat, long], zoom_start=15, tiles='OpenStreetMap')
    
#     # Folium 마커 추가        
#     for machine in machine_data:
#         folium.Marker(
#             [machine['latitude'], machine['longitude']],
#             tooltip=machine['address'],
#             icon=folium.Icon(color='blue'),
#         ).add_to(m)


#     # 지도를 HTML로 저장
#     map = m._repr_html_()  # 변수 이름 수정
    
#     return render(request, "user/machine_confirm.html", {"map":map,"machines":machines})

# # 기계의 페트병 수와 용량에 따라 마커 색상을 결정하는 함수
# def get_marker_color(machine_pet, machine_capacity):
#     if machine_capacity == 0:  # 용량이 0일 경우, 기본 파란색 사용
#         return 'blue'
    
#     ratio = machine_pet / machine_capacity
    
#     # 비율에 따른 색상 결정
#     if ratio < 0.2:
#         return 'green'         # 20% 미만: 초록색
#     elif ratio < 0.5:
#         return 'lightgreen'    # 20% 이상, 50% 미만: 연초록색
#     elif ratio < 0.75:
#         return 'orange'        # 50% 이상, 75% 미만: 주황색
#     elif ratio < 0.9:
#         return 'lightred'      # 75% 이상, 90% 미만: 연빨강색
#     else:
#         return 'red'           # 90% 이상: 빨강색

# def machine_confirm(request):
#     machines = Machine.objects.all()
#     dt = pd.read_csv("skky/data/가상기계설치2.csv")
#     # 평균 위도와 경도 계산
#     lat = dt['machine_latitude'].mean()
#     long = dt['machine_longitude'].mean()

#     # Folium 지도 생성
#     m = folium.Map([lat, long], zoom_start=15, tiles='OpenStreetMap')

#      # 마커 클러스터링 추가
#     marker_cluster = MarkerCluster().add_to(m)

#     # Folium 마커 추가
#     for machine in machines:
#         marker_color = get_marker_color(machine.machine_pet, machine.machine_capacity)

#         # 마커 추가
#         marker = folium.Marker(
#             location=[machine.machine_latitude, machine.machine_longitude],
#             tooltip=f"{machine.machine_address} - {machine.machine_pet}/{machine.machine_capacity}",
#             icon=folium.Icon(color=marker_color)
#         )

#         # 마커를 클러스터에 추가
#         marker.add_to(marker_cluster)

#     # 지도를 HTML로 저장
#     map_html = m._repr_html_()

#     return render(request, "user/machine_confirm.html", {"map": map_html})

# # machine_address를 기반으로 기계 정보를 JSON으로 반환하는 뷰
# def get_machine_info(request, machine_address):
#     try:
#         # 주소에서 '-' 앞부분만 추출
#         clean_address = machine_address.split('-')[0].strip()

#         # 기계 주소에 맞는 데이터를 검색
#         machine = Machine.objects.get(machine_address__startswith=clean_address)
        
#         # 기계 정보를 JSON으로 반환
#         machine_info = {
#             'machine_address': machine.machine_address,
#             'machine_capacity': machine.machine_capacity,
#             'machine_pet': machine.machine_pet,
#         }
#         return JsonResponse(machine_info)
#     except Machine.DoesNotExist:
#         return JsonResponse({'error': 'Machine not found'}, status=404)



# 기계의 페트병 수와 용량에 따라 마커 색상을 결정하는 함수
def get_marker_color(machine_pet, machine_capacity):
    if machine_capacity == 0:  # 용량이 0일 경우, 기본 파란색 사용
        return 'blue'
    
    ratio = machine_pet / machine_capacity
    
    # 비율에 따른 색상 결정
    if ratio < 0.2:
        return 'lightgreen'         # 20% 미만: 연초록색
    elif ratio < 0.5:
        return 'green'    # 20% 이상, 50% 미만: 초록색
    elif ratio < 0.75:
        return 'orange'        # 50% 이상, 75% 미만: 주황색
    elif ratio < 0.9:
        return 'pink'      # 75% 이상, 90% 미만: 연빨강색
    else:
        return 'red'           # 90% 이상: 빨강색

# # 기계 정보 페이지 렌더링 함수
# def machine_confirm(request):
#     machines = Machine.objects.all()
#     dt = pd.read_csv("skky/data/가상기계설치2.csv")
#     # 평균 위도와 경도 계산
#     lat = dt['machine_latitude'].mean()
#     long = dt['machine_longitude'].mean()

#     # Folium 지도 생성
#     m = folium.Map([lat, long+0.0111], zoom_start=15, tiles='OpenStreetMap')


#     # 각 기계에 대해 마커 추가
#     for machine in machines:
#         marker_color = get_marker_color(machine.machine_pet, machine.machine_capacity)
        
#         # 팝업에 표시할 HTML 내용 (글자 크기 조정)
#         popup_text = f"""
#         <div style="font-size: 13px;">
#             <b>주소:</b> {machine.machine_address}<br>
#             <b>페트병 수:</b> {machine.machine_pet}<br>
#             <b>수용량:</b> {machine.machine_capacity}<br>
#             <b>사용 가능 여부:</b> {'사용 가능' if machine.machine_pet < machine.machine_capacity else '사용 불가능'}
#         </div>
#         """
        
#         # 마커 및 팝업 추가
#         folium.Marker(
#             location=[machine.machine_latitude, machine.machine_longitude],
#             popup=folium.Popup(popup_text, max_width=300),
#             icon=folium.Icon(color=marker_color)
#         ).add_to(m)

#     # Folium 지도 HTML로 변환
#     map_html = m._repr_html_()

#     # 기계 정보 전달 (표에도 표시)
#     return render(request, "user/machine_confirm.html", {"map": map_html, "machines": machines})


# 기계 정보 페이지 렌더링 함수
def machine_confirm(request):
    machines = Machine.objects.all()
    dt = pd.read_csv("skky/data/가상기계설치2.csv")
    
    # 평균 위도와 경도 계산
    lat = dt['machine_latitude'].mean()
    long = dt['machine_longitude'].mean()

    # Folium 지도 생성
    m = folium.Map([lat, long+0.007], zoom_start=15, tiles='OpenStreetMap')

    # 중복된 좌표 처리용 오프셋 범위 설정
    def add_offset(lat, lon, offset_range=0.0001):
        """기존 좌표에 약간의 오프셋을 추가하여 마커가 겹치지 않도록 합니다."""
        # float으로 변환하여 문자열 결합 오류 방지
        lat = float(lat)
        lon = float(lon)
        offset_lat = random.uniform(-offset_range, offset_range)
        offset_lon = random.uniform(-offset_range, offset_range)
        return lat + offset_lat, lon + offset_lon

    # 각 기계에 대해 마커 추가
    for machine in machines:
        marker_color = get_marker_color(machine.machine_pet, machine.machine_capacity)
        
        # 중복되는 좌표를 피하기 위해 약간의 오프셋 추가
        lat, lon = add_offset(machine.machine_latitude, machine.machine_longitude)
        
        # 팝업에 표시할 HTML 내용 (글자 크기 조정)
        popup_text = f"""
        <div style="font-size: 13px;">
            <b>주소:</b> {machine.machine_address}<br>
            <b>페트병 수:</b> {machine.machine_pet}<br>
            <b>수용량:</b> {machine.machine_capacity}<br>
            <b>사용 가능 여부:</b> {'사용 가능' if machine.machine_pet < machine.machine_capacity else '사용 불가능'}
        </div>
        """
        
        # 마커 및 팝업 추가
        folium.Marker(
            location=[lat, lon],  # 오프셋이 적용된 좌표
            popup=folium.Popup(popup_text, max_width=300),
            icon=folium.Icon(color=marker_color)
        ).add_to(m)

    # Folium 지도 HTML로 변환
    map_html = m._repr_html_()

    # 기계 정보 전달 (표에도 표시)
    return render(request, "user/machine_confirm.html", {"map": map_html, "machines": machines})



# machine_address를 기반으로 기계 정보를 JSON으로 반환하는 뷰
def get_machine_info(request, machine_address):
    try:
        # 주소에서 '-' 앞부분만 추출
        clean_address = machine_address.split('-')[0].strip()

        # 기계 주소에 맞는 데이터를 검색
        machine = Machine.objects.get(machine_address__startswith=clean_address)
        
        # 기계 정보를 JSON으로 반환
        machine_info = {
            'machine_address': machine.machine_address,
            'machine_capacity': machine.machine_capacity,
            'machine_pet': machine.machine_pet,
        }
        return JsonResponse(machine_info)
    except Machine.DoesNotExist:
        return JsonResponse({'error': 'Machine not found'}, status=404)
    

    
### 리워드 상품 확인 페이지

def reward_confirm(request):
    if request.method == 'POST':
        # POST 요청으로 전달된 선택된 제품 ID 받기
        product_id = request.POST.get('selected_product')  # "selected_product"와 일치

        print(f"선택된 제품 ID: {product_id}")

        if product_id:
            # 선택한 제품을 데이터베이스에서 가져오기
            product = get_object_or_404(Product, id=product_id)

            # 선택된 제품 정보를 exchange.html에 전달
            return render(request, 'exchange/exchange.html', {'pro': product})

    # GET 요청일 경우 기본 reward_confirm 페이지 표시
    products = Product.objects.all()  # 모든 제품 가져오기
    return render(request, 'user/reward_confirm.html', {'products': products})





############################## 챗봇 ##############################
# 챗봇 페이지 렌더링
def chatbot_view(request):
    return render(request, 'chat.html')

# Rasa 서버와 통신하는 API
def rasa_response(request):
    if request.method == 'POST':
        user_message = request.POST.get('message')  # 사용자가 보낸 메시지

        # Rasa 서버로 요청을 전송
        # rasa_url = 'https://151a-220-93-212-179.ngrok-free.app/webhooks/rest/webhook'  # Rasa 서버 URL
        rasa_url = 'http://127.0.0.1:5005/webhooks/rest/webhook'  # Rasa 서버 URL
        payload = {"sender": "user", "message": user_message}
        headers = {"Content-Type": "application/json"}

        # Rasa로부터 응답 받기
        response = requests.post(rasa_url, json=payload, headers=headers)
        rasa_reply = response.json()

        if rasa_reply:
            bot_message = rasa_reply[0].get('text', '알 수 없는 응답입니다.')
        else:
            bot_message = '챗봇이 응답할 수 없습니다.'

        return JsonResponse({'message': bot_message})  # JSON으로 응답 반환

    return JsonResponse({'message': '잘못된 요청입니다.'})



