# from django.urls import re_path
# from skky import consumers

# websocket_urlpatterns = [
#     re_path(r'ws/camera/', consumers.CameraConsumer.as_asgi()),
# ]
from django.urls import path
from skky import consumers

websocket_urlpatterns = [
    path('ws/camera/', consumers.YoloConsumer.as_asgi()),  # '/ws/camera/'로 라우팅 설정
]
