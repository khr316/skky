from django.urls import path
from skky import views  # views.py에서 정의한 로그인 뷰를 가져옴


urlpatterns = [
    
    path('', views.main, name='main'),  # 메인 페이지로 리디렉션 (임시로 main view가 필요)
    path("login/", views.login_action, name='login'),  # 로그인 URL 추가
    path("signup/", views.signup, name='signup'), # 회원가입 URL 추가
    path("logout/", views.logout_action, name='logout'),
    path('aboutus/', views.aboutus, name='aboutus'),
    path('admin_main/', views.admin_main, name='관리자용'),
    path('check_username/', views.check_username, name='check_username'),
    path('find_id/', views.find_id, name="아이디찾기"),
    path('find_pw/', views.find_pw, name='비밀번호찾기'),
    path('change_password,', views.change_password, name="비밀번호변경"),
    
    
    # path('statistics/', views.statistics_page, name='통계페이지'),
    
    #################### 챗봇 ####################
    path('chat/', views.chatbot_view, name='chatbot_view'),  # 챗봇 페이지
    path('chatbot/response/', views.rasa_response, name='rasa_response'),  # Rasa와 통신하는 API
        
    #################### 관리자 ver ####################
    path('machine/', views.machine, name='기계정보'), 
    path('machine/collect/<int:machine_id>/', views.collect_machine, name='기계수거'),  # 수거 완료 URL 추가
    path('machine/edit/<int:machine_id>/', views.machine_edit, name='기계수정'),
    
    path('user/',views.user, name='회원정보'),
    path('user/delete/<int:user_id>/', views.delete_user, name='탈퇴'),
    path('user/detail/<int:user_id>/', views.user_detail, name='회원상세정보'),
    
    path('product/', views.product, name='상품정보'),
    path('product/upload/', views.product_upload, name='상품등록'),
    path('product/delete/<int:product_id>/', views.product_delete, name='상품삭제'),
    path('product/edit/<int:product_id>/', views.product_edit, name='상품수정'),
    path("reg_gift/", views.reg_gift, name='교환신청내역'),
    path("delivery_complete/<int:exchange_id>/", views.delivery_complete, name='배송완료'),
    path("delivery_complete1/<int:exchange_id>/", views.delivery_complete1, name='수령완료'),
    
    
    #################### 사용자 ver ####################
    path("mypage/", views.mypage, name='마이페이지'),
    path("reward_del/", views.cancel_exchange, name="교환취소"),
    # path('user/delete/<int:user_id>/', views.delete_user, name='탈퇴'),
    path("update_phone/", views.update_phone, name='정보수정'),
    path('reward_action/', views.reward_action, name='교환신청액션'), # 수령 방법, 주소 등 입력 폼
    path('reward_action_action', views.reward_action_action, name='교환신청제출'), # 폼 액션
    
    path('petpet/', views.petpet, name='페트병투입'), # 페트병 투입 하는 장면 보여줄 페이지
    path('petpet_action/', views.petpet_action, name='투입하기'),
    path('petpetpet_action/', views.petpetpet_action, name='찐투입'),

    path('stop_yolo_webcam/', views.stop_yolo_webcam, name='stop_yolo_webcam'),
    
    path("machine_confirm/", views.machine_confirm, name="기계위치확인"),
    path('get_machine_info/<str:machine_address>/', views.get_machine_info, name='get_machine_info'),
    path("reward_confirm/", views.reward_confirm, name="상품확인"),
    path("exchange_history/", views.exchange_history, name="교환내역"),

]
