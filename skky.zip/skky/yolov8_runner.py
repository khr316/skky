# import multiprocessing
# from ultralytics import YOLO
# import cv2
# import time

# class Yolov8Model:
#     def __init__(self, model_path):
#         self.model = YOLO(model_path)

#     def process_frame(self, frame):
#         results = self.model(frame)
#         return results[0].plot()

# def run_model(model_path, frame_queue, results_queue, model_num, is_running):
#     yolov8_model = Yolov8Model(model_path)
#     while is_running.value:
#         if not frame_queue.empty():
#             frame = frame_queue.get()
#             processed_frame = yolov8_model.process_frame(frame)
#             results_queue.put((model_num, processed_frame))
#         time.sleep(1)
#     print(f"모델 {model_num} 종료")  # 종료 시 로그 출력

# def run_yolov8_models(is_running, frame_queue):
#     model_paths = [
#         "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/내용물runs/detect/train/weights/best.pt",
#         "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/뚜껑2runs/detect/train/weights/best.pt",
#         "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/뚜껑runs/detect/train/weights/best.pt",
#         "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/라벨,뚜껑runs/detect/train/weights/best.pt",
#         "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/투명runs/detect/train/weights/best.pt"
#     ]
    
#     results_queue = multiprocessing.Queue()
#     processes = []

#     for i, model_path in enumerate(model_paths):
#         p = multiprocessing.Process(target=run_model, args=(model_path, frame_queue, results_queue, i, is_running))
#         p.start()
#         processes.append(p)

#     return processes, results_queue
import multiprocessing
from ultralytics import YOLO
import cv2
import time

# Yolov8 모델 클래스 정의
class Yolov8Model:
    def __init__(self, model_path):
        self.model = YOLO(model_path)

    def process_frame(self, frame):
        results = self.model(frame)
        counts = {i: 0 for i in range(5)}  # 0~4까지의 클래스를 카운트하기 위한 딕셔너리
        for result in results:
            for detection in result.boxes:
                cls = int(detection.cls)  # 감지된 클래스
                if cls in counts:
                    counts[cls] += 1  # 해당 클래스의 카운트 증가
        return results[0].plot(), counts  # 처리된 이미지와 클래스별 개수 반환

def run_model(model_path, frame_queue, results_queue, model_num, is_running):
    yolov8_model = Yolov8Model(model_path)
    while is_running.value:
        if not frame_queue.empty():
            frame = frame_queue.get()  # 큐에서 프레임 가져오기
            processed_frame, counts = yolov8_model.process_frame(frame)  # Yolov8 모델로 처리
            results_queue.put((model_num, processed_frame, counts))  # 처리된 결과와 카운트 큐에 넣기
        time.sleep(1)
    print(f"모델 {model_num} 종료")

def run_yolov8_models(is_running, frame_queue):
    model_paths = [
        # "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/내용물runs/detect/train/weights/best.pt",
        # "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/뚜껑2runs/detect/train/weights/best.pt",
        # "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/뚜껑runs/detect/train/weights/best.pt",
        # "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/라벨,뚜껑runs/detect/train/weights/best.pt",
        # "C:/Users/TK/Desktop/기업프로젝트0925_오후/yolov8학습됨/투명runs/detect/train/weights/best.pt"
        "C:/Users/user/Desktop/skky-통합code/통합/runs/detect/train3/weights/best.pt"
    ]
    
    results_queue = multiprocessing.Queue()
    processes = []

    for i, model_path in enumerate(model_paths):
        p = multiprocessing.Process(target=run_model, args=(model_path, frame_queue, results_queue, i, is_running))
        p.start()
        processes.append(p)

    return processes, results_queue
