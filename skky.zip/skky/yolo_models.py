# import cv2
# import socketio
# import base64
# from ultralytics import YOLO  # YOLOv8 모델 가져오기
# import json

# # Socket.IO 클라이언트 연결
# sio = socketio.Client()

# @sio.event
# def connect():
#     print('연결되었습니다.')
#     # 연결 메시지도 JSON으로 보냄
#     sio.emit('status', json.dumps({"message": "연결되었습니다."}))

# sio.connect('http://localhost:3000', transports=['websocket', 'polling'])

# # YOLOv8 모델 경로
# model_paths = [
#     "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/내용물runs/detect/train/weights/best.pt",
#     "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/뚜껑2runs/detect/train/weights/best.pt",
#     "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/뚜껑runs/detect/train/weights/best.pt",
#     "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/라벨,뚜껑runs/detect/train/weights/best.pt",
#     "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/투명runs/detect/train/weights/best.pt"
# ]

# models = [YOLO(path) for path in model_paths]  # YOLO 모델 로드
# cap = cv2.VideoCapture(0)  # 웹캠 열기

# def send_frame(frame, counts):
#     _, buffer = cv2.imencode('.jpg', frame)
#     frame_base64 = base64.b64encode(buffer).decode('utf-8')
#     data = json.dumps({'image': frame_base64, 'counts': counts})
#     sio.emit('yolo_frame', data)

# def process_frame(frame):
#     all_counts = [0, 0, 0, 0, 0]
#     processed_frame = frame
#     for i, model in enumerate(models):
#         results = model(frame)
#         processed_frame = results[0].plot()
#         all_counts[i] = len(results[0].boxes)
#     return processed_frame, all_counts

# while cap.isOpened():
#     ret, frame = cap.read()
#     if not ret:
#         break

#     processed_frame, counts = process_frame(frame)
#     send_frame(processed_frame, counts)

# cap.release()
# sio.disconnect()



import cv2
import socketio
import base64
from ultralytics import YOLO
import json

# Socket.IO 클라이언트 설정
sio = socketio.Client()

# YOLOv8 모델 경로
model_paths = [
    # "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/내용물runs/detect/train/weights/best.pt",
    # "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/뚜껑2runs/detect/train/weights/best.pt",
    # "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/뚜껑runs/detect/train/weights/best.pt",
    # "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/라벨,뚜껑runs/detect/train/weights/best.pt",
    # "C:/Users/TK/Desktop/skky-1007/yolov8학습됨/투명runs/detect/train/weights/best.pt"
    "C:/Users/user/Desktop/skky-통합code/통합/runs/detect/train3/weights/best.pt"
]

# 5개의 YOLOv8 모델을 불러오기
models = [YOLO(path) for path in model_paths]

# 웹캠 열기
cap = cv2.VideoCapture(0)

@sio.event
def connect():
    print('연결되었습니다.')
    sio.emit('status', json.dumps({"message": "연결되었습니다."}, ensure_ascii=False))

# 서버 연결
sio.connect('http://localhost:3000', transports=['websocket', 'polling'])

def send_frame(frame, counts):
    # 이미지를 JPEG로 인코딩하고 base64로 변환
    _, buffer = cv2.imencode('.jpg', frame)
    frame_base64 = base64.b64encode(buffer).decode('utf-8')
    
    # JSON 형태로 이미지와 객체 개수를 전송
    data = json.dumps({'image': frame_base64, 'counts': counts})
    sio.emit('webcam_data', data)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # 모델별로 예측 수행
    all_counts = [0] * len(models)  # 각 모델의 객체 수 저장
    for i, model in enumerate(models):
        results = model(frame)

        # 각 모델의 감지된 객체 수를 저장
        all_counts[i] = len(results[0].boxes)

        # 감지된 객체를 플로팅하여 이미지에 표시
        frame = results[0].plot()

    # 결과 전송 (5개 모델의 감지된 객체 수 포함)
    send_frame(frame, all_counts)

cap.release()
sio.disconnect()
