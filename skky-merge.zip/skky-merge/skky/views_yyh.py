from django.shortcuts import get_object_or_404, render, redirect
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.contrib.auth import login
from django.contrib import messages
from .models import User, Product, Exchange, Delivery, Machine, MachineUser
from django.contrib.auth.decorators import login_required
from django import forms



@login_required
def mypage(request):
    return render(request, 'user/mypage.html')

# 전화번호 수정 폼
@login_required
def update_phone(request):
    var_user_phone = request.POST.get('input_user_phone')

    user_object = User.objects.get(id = request.user.id)

    user_object.user_phone = var_user_phone
    user_object.save()

    return redirect('마이페이지')

def reg_gift(request):
    all_exchange_list = Exchange.objects.select_related('user', 'product').all()
    print(all_exchange_list)  # 로그에 출력
    context = {
        'exchange_list': all_exchange_list,
    }
    return render(request, 'manage/reg_gift.html', context)
