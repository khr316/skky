from django.apps import AppConfig


class SkkyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "skky"
