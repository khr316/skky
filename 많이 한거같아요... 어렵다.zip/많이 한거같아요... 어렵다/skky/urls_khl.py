from django.urls import path
from skky import views_khl  # views.py에서 정의한 로그인 뷰를 가져옴

urlpatterns = [
    
]
