from ultralytics import YOLO
import cv2

# YOLO 모델 경로
model_paths = [
    'C:/Users/user/Desktop/yolov8학습됨/train15/weights/best.pt',
    'C:/Users/user/Desktop/yolov8학습됨/내용물runs/detect/train/weights/best.pt',  # 내용물
    'C:/Users/user/Desktop/yolov8학습됨/뚜껑2runs/detect/train/weights/best.pt',  # 뚜껑2
    'C:/Users/user/Desktop/yolov8학습됨/뚜껑runs/detect/train/weights/best.pt',  # 뚜껑
    'C:/Users/user/Desktop/yolov8학습됨/라벨,뚜껑runs/detect/train/weights/best.pt',  # 라벨, 뚜껑
    'C:/Users/user/Desktop/yolov8학습됨/투명runs/detect/train/weights/best.pt'  # 투명
]

# 모델들을 리스트에 로드
models = [YOLO(path) for path in model_paths]

# 클래스에 따른 메시지 정의
CLASS_MESSAGES = {
    0: "성공: 투명 페트병입니다.",
    1: "라벨 제거 후 다시 넣어주세요.",
    2: "성공: 뚜껑이 없습니다.",
    4: "내용물 비운 후 다시 넣어주세요."
}

def run_yolo_webcam():
    """
    웹캠을 통해 실시간으로 YOLO 모델을 사용하여 물체 감지를 수행합니다.
    각 프레임에서 감지된 객체의 클래스에 따라 메시지를 반환합니다.
    """
    source = 0
    cap = cv2.VideoCapture(source)

    if not cap.isOpened():
        print("웹캠을 열 수 없습니다.")
        return {'message': '웹캠을 열 수 없습니다.', 'class': None}

    detection_result = {'message': '', 'class': None}

    # 한 프레임만 추론하도록 구현
    ret, frame = cap.read()
    if not ret:
        print("프레임을 읽을 수 없습니다.")
        cap.release()
        return {'message': '프레임을 읽을 수 없습니다.', 'class': None}

    # 모든 모델에 대해 추론 실행
    for model in models:
        results = model.predict(frame)

        # 감지된 객체에 대한 메시지 및 바운딩 박스 표시
        for result in results:
            for box in result.boxes:
                label = int(box.cls)  # 클래스 레이블 (정수형으로 변환)

                # 메시지 업데이트
                message = CLASS_MESSAGES.get(label, "알 수 없는 객체")
                detection_result['message'] = message
                detection_result['class'] = label

                # 클래스 0 또는 2일 경우 성공이므로 감지를 중지하기 위해 반환
                if label in [0, 2]:
                    cap.release()
                    return detection_result

    cap.release()
    return detection_result
